/* schema */
create schema voebem ;
use voebem ;


/* passageiro */
create table passageiro (
    passageiro_id int auto_increment primary key,
    nome varchar(200) not null,
    dt_nascimento date not null,
    numero_documento varchar(45) not null,
    dt_cadastro timestamp not null default current_timestamp );

insert into passageiro (nome, dt_nascimento, numero_documento) values('Ana da Silva', '1981-01-01','020.987.778-1');
insert into passageiro (nome, dt_nascimento, numero_documento) values('Beatriz da Silva','1982-02-02','020.987.778-2');
insert into passageiro (nome, dt_nascimento, numero_documento) values('Carlos da Silva','1983-03-03','020.987.778-3');
insert into passageiro (nome, dt_nascimento, numero_documento) values('Durval da Silva','1984-04-04','020.987.778-4');
insert into passageiro (nome, dt_nascimento, numero_documento) values('Eliana da Silva','1985-05-05','020.987.778-5');
insert into passageiro (nome, dt_nascimento, numero_documento) values('Kelly da Silva','1986-06-06','020.987.778-5'); 

/* aeroporto */
create table aeroporto (
  aeroporto_id int auto_increment primary key,
  nome varchar(200) not null,
  cidade varchar(150) not null,
  estado varchar(2) not null,
  pais varchar(45) not null,
  aberto bit not null default true,
  dt_cadastro timestamp not null default current_timestamp);

insert into aeroporto (nome, cidade, estado, pais) values ('Galeão (GIG)','Rio de Janeiro','RJ','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Santos Dumont (SDU)','Rio de Janeiro','RJ','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Brasília (BSB)','Brasília','DF','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Belém (BEL)','Belém','PA','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Congonhas (CGH)','São Paulo','SP','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Porto Alegre (POA)','Porto Alefre','RS','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Fortaleza (FOR)','Fortaleza','CE','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Confins (CNF)','Belo Horizonte','MG','Brasil');
insert into aeroporto (nome, cidade, estado, pais) values ('Lisboa (LIS)','Lisboa','LB','Portugal');

/* trecho */
create table trecho(
    trecho_id int auto_increment primary key,
    aeroporto_id_origem int not null,
    aeroporto_id_destino int not null,
    tempo_voo time not null,
    status varchar(45) not null,
    dt_cadastro timestamp not null default current_timestamp,
    constraint fk_trecho_aeroporto_origem foreign key (aeroporto_id_origem) references aeroporto (aeroporto_id),
    constraint fk_trecho_aeroporto_destino foreign key (aeroporto_id_destino) references aeroporto(aeroporto_id));

insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(1,3,'01:03','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(1,5,'00:40','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(2,8,'00:37','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(1,9,'08:00','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(3,4,'01:40','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(4,2,'03:50','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(9,5,'08:40','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(6,7,'03:00','Ativo');
insert into trecho (aeroporto_id_origem, aeroporto_id_destino, tempo_voo,status) values(7,6,'03:00','Ativo');


/* aeronave */
create table aeronave (
  aeronave_id int auto_increment primary key,
  nome varchar(45) not null,
  tipo varchar(45) not null,
  status varchar(45) not null,
  dt_cadastro timestamp not null default current_timestamp);

insert into aeronave(nome,tipo, status) values('Airbus A320','Jato Comercial','Ativo');
insert into aeronave(nome,tipo, status) values('Boeing 787','Jato Comercial','Ativo');
insert into aeronave(nome,tipo, status) values('Bombardier Challenger 350','Jato Executivo','Ativo');
insert into aeronave(nome,tipo, status) values('Phenom 300','Jato Executivo','Ativo');


/* assento */
create table assento (
  assento_id int auto_increment primary key,
  aeronave_id int not null,
  identificacao varchar(4) not null,
  descricao varchar(20) not null,
  classe varchar(45) not null,
  constraint fk_assento_aeronave foreign key (aeronave_id) references aeronave(aeronave_id)
);

insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-02','Corredor','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-02','Corredor','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-01','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-02','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-03','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-04','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-05','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'A-06','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-01','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-02','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-03','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-04','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-05','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (1,'B-06','Corredor','Executivo');

insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-02','Corredor','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-02','Corredor','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-01','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-02','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-03','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-04','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-05','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'A-06','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-01','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-02','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-03','Corredor','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-04','Janela','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-05','Meio','Executivo');
insert into assento (aeronave_id,identificacao, descricao,classe) values (2,'B-06','Corredor','Executivo');

insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'A-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'A-02','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'B-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'B-02','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'C-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'C-02','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'D-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (3,'D-02','Janela','Primeira classe');

insert into assento (aeronave_id,identificacao, descricao,classe) values (4,'A-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (4,'B-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (4,'C-01','Janela','Primeira classe');
insert into assento (aeronave_id,identificacao, descricao,classe) values (4,'D-01','Janela','Primeira classe');


/* voo */
create table voo (
    voo_id int not null auto_increment primary key,
    numero int not null,
    status varchar(45) not null,
    dt_cadastro timestamp not null default current_timestamp);

insert into voo (numero, status) values(1000,'Em reserva');
insert into voo (numero, status) values(2000,'Em reserva');
insert into voo (numero, status) values(3000,'Lotado');
insert into voo (numero, status) values(4000,'Em reserva');
insert into voo (numero, status) values(5000,'Cancelado');
insert into voo (numero, status) values(6000,'Em reserva');
insert into voo (numero, status) values(7000,'Em reserva');
insert into voo (numero, status) values(8000,'Em reserva');

/* trecho_voo */
create table trecho_voo (
    voo_id int not null,
    trecho_id int not null,
    dt_embarque_previsto datetime not null,
    dt_desembarque_previsto datetime not null,
    dt_embarque datetime ,
    dt_desembarque datetime ,
    mensagem varchar(100) null,
    dt_cadastro timestamp not null default current_timestamp,
    primary key (voo_id, trecho_id),
    constraint fk_trecho_voo_voo foreign key (voo_id) references voo (voo_id),
    constraint fk_trecho_voo_trecho foreign key (trecho_id) references trecho (trecho_id));

insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (1,      1,     '2022-06-15 12:00:00', '2022-06-15 13:30:00',  '2022-06-15','Voo atrasado', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (2,      2,     '2022-06-10 18:00:00', '2022-06-10 23:30:00',  '2022-06-10','Cancelado', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (3,      3,     '2022-06-30 11:00:00', '2022-06-30 14:30:00',  '2022-06-30','Sem previsão', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (4,      4,     '2022-06-16 08:00:00', '2022-06-16 13:30:00',  '2022-06-16','Confirmado', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (5,      5,     '2022-06-20 23:00:00', '2022-06-21 01:30:00',  '2022-06-20','Confirmado', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (6,      5,     '2022-06-25 15:00:00', '2022-06-25 17:00:00',  '2022-06-25','Embarque Imediato', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (7,      7,     '2022-06-30 09:00:00', '2022-06-30 11:30:00',  '2022-06-30','Confirmado', default);
insert into trecho_voo (voo_id, trecho_id, dt_embarque_previsto, dt_desembarque_previsto, dt_embarque, mensagem, dt_cadastro)
				values (8,      6,     '2022-06-15 08:00:00', '2022-06-15 10:30:00',  '2022-06-15','Confirmado', default);  

/* reserva */
create table reserva (
    reserva_id int not null auto_increment primary key,
    voo_id int not null,
    dt_reserva datetime not null,
    dt_validade datetime not null,
    status varchar(45) not null,
    passageiro_id int not null,
    dt_cadastro timestamp not null default current_timestamp,
    constraint fk_reserva_passageiro foreign key (passageiro_id) references passageiro(passageiro_id),
    constraint fk_reserva_voo foreign key (voo_id) references voo(voo_id)
    ); 
	
insert into reserva (reserva_id, voo_id, dt_reserva, dt_validade, status, passageiro_id, dt_cadastro) values ('1', '1', '2022-06-04', '2022-08-04', 'cadastrado', '1', '2022-08-05 17:59');
insert into reserva (reserva_id, voo_id, dt_reserva, dt_validade, status, passageiro_id, dt_cadastro) values ('2', '2', '2022-06-05', '2022-08-05', 'cadastrado', '2', '2022-08-05 18:00');
insert into reserva (reserva_id, voo_id, dt_reserva, dt_validade, status, passageiro_id, dt_cadastro) values ('3', '3', '2022-07-06', '2022-07-06', 'cadastrado', '3', '2022-08-05 19:00');
insert into reserva (reserva_id, voo_id, dt_reserva, dt_validade, status, passageiro_id, dt_cadastro) values ('4', '4', '2022-06-07', '2022-08-07', 'cadastrado', '4', '2022-08-05 20:00');
insert into reserva (reserva_id, voo_id, dt_reserva, dt_validade, status, passageiro_id, dt_cadastro) values ('5', '5', '2022-06-08', '2022-08-08', 'cadastrado', '5', '2022-08-05 21:00');

/* reserva_trecho */
create table reserva_trecho (
    reserva_id int not null,
    voo_id int not null,
    trecho_id int not null,
    assento_id int not null,
    dt_emissao_bilhete datetime null,
    dt_cadastro datetime not null,
    primary key (reserva_id, voo_id, trecho_id, assento_id),
    constraint fk_reserva_trecho_reserva foreign key (reserva_id) references reserva (reserva_id),
    constraint fk_reserva_trecho_trecho_voo foreign key (voo_id, trecho_id) references trecho_voo (voo_id, trecho_id),
    constraint fk_reserva_trecho_assento foreign key (assento_id) references assento (assento_id)); 
	
insert into `voebem`.`reserva_trecho` (`reserva_id`, `voo_id`, `trecho_id`, `assento_id`, `dt_emissao_bilhete`, `dt_cadastro`) values ('1', '1', '1', '1', '2022-06-04 18:00', '2022-06-04 18:00');
insert into `voebem`.`reserva_trecho` (`reserva_id`, `voo_id`, `trecho_id`, `assento_id`, `dt_emissao_bilhete`, `dt_cadastro`) values ('2', '2', '2', '2', '2022-06-04 18:01', '2022-06-04 18:01');
insert into `voebem`.`reserva_trecho` (`reserva_id`, `voo_id`, `trecho_id`, `assento_id`, `dt_emissao_bilhete`, `dt_cadastro`) values ('3', '3', '3', '3', '2022-06-04 18:02', '2022-06-04 18:02');
insert into `voebem`.`reserva_trecho` (`reserva_id`, `voo_id`, `trecho_id`, `assento_id`, `dt_emissao_bilhete`, `dt_cadastro`) values ('4', '4', '4', '4', '2022-06-04 18:03', '2022-06-04 18:03');
insert into `voebem`.`reserva_trecho` (`reserva_id`, `voo_id`, `trecho_id`, `assento_id`, `dt_emissao_bilhete`, `dt_cadastro`) values ('5', '5', '5', '5', '2022-06-04 18:04', '2022-06-04 18:04');

