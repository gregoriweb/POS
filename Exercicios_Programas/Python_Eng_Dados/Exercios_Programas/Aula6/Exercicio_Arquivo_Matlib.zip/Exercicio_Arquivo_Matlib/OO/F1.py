#5 maiores vencedores por nacionalidade
#5 maiores vencedores por equipe

class F1:

    def __init__(self) -> None:
        self.piloto =""
        self.equipe =""
        self.anocampeao = 0
        self.nacionalidade = ""
    